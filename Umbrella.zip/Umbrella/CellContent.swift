
import UIKit

class CellContent {
    
    var temperature: String
    var humidity: String
    var wind: String
    var pressure: String
    var icon: UIImage
    
    init(temperature: String, humidity: String, wind: String, pressure: String, icon: UIImage) {
        self.temperature = temperature
        self.humidity = humidity
        self.wind = wind
        self.pressure = pressure
        self.icon = icon
    }
    
    func getTemperature() -> String {
        return self.temperature
    }
    
    func getHumidity() -> String {
        return self.humidity
    }
    
    func getWind() -> String {
        return self.wind
    }
    
    func getPressure() -> String {
        return self.pressure
    }
    
    func getIcon() -> UIImage {
        return self.icon
    }

}
