
import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var windLabel: UILabel!
    @IBOutlet weak var pressureLabel: UILabel!
    
    func setContent(content: CellContent) {
        temperatureLabel.text = content.getTemperature()
        weatherIcon.image = content.getIcon()
        humidityLabel.text = content.getHumidity()
        windLabel.text = content.getWind()
        pressureLabel.text = content.getPressure()
    }
    
}
