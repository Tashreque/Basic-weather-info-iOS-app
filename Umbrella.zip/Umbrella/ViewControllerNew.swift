import UIKit
import CoreLocation

class ViewControllerNew: UIViewController, UITableViewDelegate, UITableViewDataSource, CLLocationManagerDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var weeklyIcon: UIImageView!
    @IBOutlet weak var weekSummary: UILabel!
    let locationManager = CLLocationManager()
    var contents: [CellContent] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    func setWeekDescription(weekIcon: String, weeklySummary: String) {
        weekSummary.text = weeklySummary
        if(weekIcon == "rain") {
            weeklyIcon.image = UIImage(named: "rainyIcon")
        }else {
            weeklyIcon.image = UIImage(named: "sunnyIcon")
        }
        return
    }
    
    func fillTableCells(latitude: Double, longitude: Double) {
        
        let latString = String(latitude)
        let longString = String(longitude)
        let weather = weatherInfo(latString, longString)
        
        let summaryOfWeek = weather.getWeekSummary()
        let iconOfWeek = weather.getWeekIcon()
        
        setWeekDescription(weekIcon: iconOfWeek, weeklySummary: summaryOfWeek)
        
        let temperatures: [String] = weather.getTemperature()
        let winds: [String] = weather.getWind()
        let humidities: [String] = weather.getHumidity()
        let icons: [String] = weather.getRain()
        let pressures: [String] = weather.getPressure()
        
        var i = 0
        while(i < temperatures.count) {
            if(icons[i] == "rain") {
                if let image = UIImage(named: "rainyIcon") {
                    let content = CellContent(temperature: temperatures[i], humidity: humidities[i], wind: winds[i], pressure: pressures[i], icon: image)
                    
                    contents.append(content)
                }
            }else {
                if let image = UIImage(named: "sunnyIcon") {
                    let content = CellContent(temperature: temperatures[i], humidity: humidities[i], wind: winds[i], pressure: pressures[i], icon: image)
                    
                    contents.append(content)
                }
            }
            i = i + 1
        }
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    
    
    
    
    //TableView delegate methods
    //Handler functions
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contents.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let content = contents[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        cell.setContent(content: content)
        
        return cell
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let locationValue: CLLocationCoordinate2D = manager.location?.coordinate {
            print("\(locationValue.latitude), \(locationValue.longitude)")
            
            fillTableCells(latitude: locationValue.latitude, longitude: locationValue.longitude)
        }
    }

}
