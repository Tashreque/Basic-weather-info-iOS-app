
import UIKit
import CoreLocation

class ViewController: UIViewController, UISearchBarDelegate, CLLocationManagerDelegate {
    
    let locationManager = CLLocationManager()
    var option = false
    var lat: Double = 0.0
    var long: Double = 0.0
    
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var rainLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var windLabel: UILabel!
    @IBOutlet weak var umbrellaLogo: UIImageView!
    @IBOutlet weak var visualWindow: UIVisualEffectView!
    @IBOutlet weak var backgroundImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        searchBar.delegate = self
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
//        let weather = weatherInfo()
//        temperatureLabel.text = weather.getTemperature(searchBar.text!)
//        humidityLabel.text = weather.getHumidity(searchBar.text!)
//        windLabel.text = weather.getWind(searchBar.text!)
//        descriptionLabel.text = weather.getRain(searchBar.text!)
        
        searchBarTextDidEndEditing(self.searchBar)
        self.view.endEditing(true)
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        self.searchBar.alpha = 0.6
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        self.searchBar.text = ""
        self.searchBar.alpha = 0.1
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locationValue: CLLocationCoordinate2D = manager.location!.coordinate
        lat = locationValue.latitude
        long = locationValue.longitude
        let weather = weatherInfo()
        temperatureLabel.text = weather.getTemperature(String(lat), String(long))
        humidityLabel.text = weather.getHumidity(String(lat), String(long))
        windLabel.text = weather.getWind(String(lat), String(long))
        rainLabel.text = weather.getRain(String(lat), String(long))
        print(rainLabel.text!)
        descriptionLabel.text = weather.getSummary(String(lat), String(long))
        print(descriptionLabel.text!)
        
        print("\(locationValue.latitude), \(locationValue.longitude)")
    }

}

