
import Foundation

struct weather: Decodable {
    
    let currently: parameters
}

struct parameters: Decodable {
    let summary: String
    let pressure: Double
    let humidity: Double
    let windSpeed: Double
    let temperature: Double
    let icon: String
}

struct tZone: Decodable {
    let timezone: String
}

//struct coordinates: Decodable {
//    let coord: coordData
//}
//
//struct coordData: Decodable {
//    let lon: Double
//    let lat: Double
//}

class weatherInfo {
    
    private static var res = ""
    public func getTemperature(_ lat:String, _ long:String) -> String {
        let weatherURL = URL(string: "https://api.darksky.net/forecast/dd572c0ab9cc3d172b59ca4591081580/\(lat),\(long)")!
        var result = ""
        do {
            let data = try Data(contentsOf: weatherURL)
            let decode = try JSONDecoder().decode(weather.self, from: data)
            result = String(decode.currently.temperature) + "ºC"
        }catch {
            print("Error!")
        }
        
        return result
    }
    
    
    public func getHumidity(_ lat:String, _ long:String) -> String {
        let weatherURL = URL(string: "https://api.darksky.net/forecast/dd572c0ab9cc3d172b59ca4591081580/\(lat),\(long)")!
        var result = ""
        do {
            let data = try Data(contentsOf: weatherURL)
            let decode = try JSONDecoder().decode(weather.self, from: data)
            result = String(decode.currently.humidity)
        }catch {
            print("Error!")
        }
        
        return result
    }
    
    
    public func getWind(_ lat:String, _ long:String) -> String {
        let weatherURL = URL(string: "https://api.darksky.net/forecast/dd572c0ab9cc3d172b59ca4591081580/\(lat),\(long)")!
        var result = ""
        do {
            let data = try Data(contentsOf: weatherURL)
            let decode = try JSONDecoder().decode(weather.self, from: data)
            result = String(decode.currently.windSpeed)
        }catch {
            print("Error!")
        }
        
        return result
    }
    
    public func getRain(_ lat:String, _ long:String) -> String {
        let weatherURL = URL(string: "https://api.darksky.net/forecast/dd572c0ab9cc3d172b59ca4591081580/\(lat),\(long)")!
        var result = ""
        do {
            let data = try Data(contentsOf: weatherURL)
            let decode = try JSONDecoder().decode(weather.self, from: data)
            result = String(decode.currently.icon)
        }catch {
            print("Error!")
        }
        
        return result
    }
    
    public func getSummary(_ lat:String, _ long:String) -> String {
        let weatherURL = URL(string: "https://api.darksky.net/forecast/dd572c0ab9cc3d172b59ca4591081580/\(lat),\(long)")!
        var result = ""
        do {
            let data = try Data(contentsOf: weatherURL)
            let decode = try JSONDecoder().decode(weather.self, from: data)
            result = String(decode.currently.summary)
            print(result)
        }catch {
            print("Error!")
        }
        
        return result
    }
    
}
