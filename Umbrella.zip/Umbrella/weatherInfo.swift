
import Foundation

struct weather: Decodable {
    
    let daily: parameters
}

struct parameters: Decodable {
    let summary: String
    let icon: String
    let data: [dayData]
}

struct dayData: Decodable {
    let summary: String
    let icon: String
    let pressure: Double
    let humidity: Double
    let windSpeed: Double
    let temperatureHigh: Double
    
}

class weatherInfo {
    
    var weekSummary: String = ""
    var weekIcon: String = ""
    var temperature: [String] = []
    var humidity: [String] = []
    var wind: [String] = []
    var pressure: [String] = []
    var icon: [String] = []
    var summary: [String] = []
    
    init(_ lat:String, _ long:String) {
        let weatherURL = URL(string: "https://api.darksky.net/forecast/dd572c0ab9cc3d172b59ca4591081580/\(lat),\(long)")!
        
        do {
            let data = try Data(contentsOf: weatherURL)
            let decode = try JSONDecoder().decode(weather.self, from: data)
            
            weekSummary = decode.daily.summary
            weekIcon = decode.daily.icon
            
            let dataArray = decode.daily.data
            
            for each in dataArray {
                
                temperature.append(String(Int(each.temperatureHigh)) + "º")
                humidity.append(String(each.humidity) + "%")
                wind.append(String(Int(each.windSpeed)) + " mph")
                pressure.append(String(Int(each.pressure)) + " psi")
                icon.append(each.icon)
                summary.append(each.summary)
                
            }
        }catch {
            print("Parsing error!")
        }
    }
    
    
    public func getTemperature() -> [String] {
        return self.temperature
    }
    
    
    public func getHumidity() -> [String] {
        return self.humidity
    }
    
    
    public func getPressure() -> [String] {
        return self.pressure
    }
    
    
    public func getWind() -> [String] {
        return self.wind
    }
    
    public func getRain() -> [String] {
        return self.icon
    }
    
    public func getSummary() -> [String] {
        return self.summary
    }
    
    public func getWeekSummary() -> String {
        return self.weekSummary
    }
    
    public func getWeekIcon() -> String {
        return self.weekIcon
    }
    
}
